#db_setup.py
import db_connect_string
import cx_Oracle

connection = cx_Oracle.connect(db_connect_string.getConnectString())
cursor = connection.cursor()

print("Dropping and re-creating the Notifications table...")
cursor.execute("""
        begin
            execute immediate 'drop table notifications';
            exception when others then
                if sqlcode <> -942 then
                    raise;
                end if;
        end;""")
cursor.execute("""
        create table notifications(
            user_id NUMBER not null, 
            dt VARCHAR2(11) not null,
            tm VARCHAR2(8) not null
        )""")
print("The Notifications table created!")
print("Dropping and re-creating the Places table...")
cursor.execute("""
        begin
            execute immediate 'drop table places';
            exception when others then
                if sqlcode <> -942 then
                    raise;
                end if;
        end;""")
cursor.execute("""
        create table places(
            place_id NUMBER PRIMARY KEY, 
            name VARCHAR2(20) not null,
            address VARCHAR2(100) not null,
            shape SDO_GEOMETRY not null
        )""")
print("The Places table created!")

