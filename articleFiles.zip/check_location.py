#check_location.py
import db_connect_string
import cx_Oracle

connection = cx_Oracle.connect(db_connect_string.getConnectString())
cursor = connection.cursor()

location = [46.078636, 40.000623]

cursor.execute("""
  SELECT c.name, c.address
  FROM places c
  WHERE SDO_RELATE(c.shape,
            SDO_GEOMETRY(1, 8307, NULL,
              SDO_ELEM_INFO_ARRAY(1,1,1),
              SDO_ORDINATE_ARRAY(:lat,:lon)),
              'mask=anyinteract'
) = 'TRUE' 
""", location)

rslt = cursor.fetchall()
if rslt:
  print('You are near %s located at %s' %(rslt[0][0], rslt[0][1]))

