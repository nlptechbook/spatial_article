from telegram.ext import Updater, MessageHandler, Filters, CommandHandler
from datetime import datetime

import db_connect_string
import cx_Oracle

connection = cx_Oracle.connect(db_connect_string.getConnectString())
cursor = connection.cursor()
connection.autocommit = True

def start(update, context):
  update.message.reply_text('This is a test bot designed to receive and process location data.')

def get_location(update, context):
  msg = None
  if update.edited_message:
    msg = update.edited_message
  else:
    msg = update.message
  gps = msg.location

  geodata = [gps.latitude,gps.longitude]
  cursor.execute("""
    SELECT c.name, c.address
    FROM places c
    WHERE SDO_RELATE(c.shape,
            SDO_GEOMETRY(1, 8307, NULL,
              SDO_ELEM_INFO_ARRAY(1,1,1),
              SDO_ORDINATE_ARRAY(:lat,:lon)),
              'mask=anyinteract'
    ) = 'TRUE'""", geodata)

  rslt = cursor.fetchall()

  tm = datetime.now().strftime("%H:%M:%S")
  dt = datetime.now().strftime("%d-%b-%Y")

  cursor.execute("""
    SELECT count(*)
    FROM notifications
    WHERE user_id = :chat_id and dt = :dt""", [msg.chat_id, dt])

  sent = cursor.fetchall()[0][0]

  if (rslt) and (sent == 0):
     context.bot.send_message(chat_id=msg.chat_id, text=str(gps) + 'You are near %s located at %s' %(rslt[0][0], rslt[0][1]))

     data = [msg.chat_id, dt, tm]
     cursor.execute('insert into notifications values (:chat_id, :dt, :tm)', data)


def main():
  updater = Updater('YOUR_TOKEN_HERE', use_context=True)
  updater.dispatcher.add_handler(CommandHandler("start", start))
  updater.dispatcher.add_handler(MessageHandler(Filters.location, get_location))
  updater.start_polling()
  updater.idle()
if __name__ == '__main__':
    main()

