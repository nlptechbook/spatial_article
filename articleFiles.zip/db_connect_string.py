#db_connect_string.py
DB_USER = "usr"
DB_PASSWORD = "pswd"
DB_CONNECT_STRING = "localhost/orcl"

def getConnectString():
  return "%s/%s@%s" % (DB_USER, DB_PASSWORD, DB_CONNECT_STRING)


