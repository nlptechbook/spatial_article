#insert_area.py
import db_connect_string
import cx_Oracle

connection = cx_Oracle.connect(db_connect_string.getConnectString())
cursor = connection.cursor()
connection.autocommit = True

typeObj = connection.gettype("MDSYS.SDO_GEOMETRY")
elementInfoTypeObj = connection.gettype("MDSYS.SDO_ELEM_INFO_ARRAY")
ordinateTypeObj = connection.gettype("MDSYS.SDO_ORDINATE_ARRAY")

def CreateGeometryPolygon(*coords):
    geometry = typeObj.newobject()
    geometry.SDO_GTYPE = 2003
    geometry.SDO_SRID = 8307
    geometry.SDO_ELEM_INFO = elementInfoTypeObj.newobject()
    geometry.SDO_ELEM_INFO.extend([1, 1003, 1])
    geometry.SDO_ORDINATES = ordinateTypeObj.newobject()
    geometry.SDO_ORDINATES.extend(coords)
    return geometry

pizzaRestaurant = CreateGeometryPolygon(46.080453, 39.994143, 46.079943, 39.994057, 46.077989, 40.000344, 46.078774, 40.001288, 46.080453, 39.994143)


geodata = [1, 'Pizza restaurant', '21 Cherry St', pizzaRestaurant]

cursor.execute('insert into places values (:place_id, :name, :address, :ordinates)', geodata)
print("The area defined!")

